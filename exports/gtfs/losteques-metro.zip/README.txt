Synthetic frequencies-based feed. The route topology is real, but
the schedule is approximate (every N minutes 05:00-23:00 weekdays).
Do not use for trip-planning. See sources.md in the upstream repo.
